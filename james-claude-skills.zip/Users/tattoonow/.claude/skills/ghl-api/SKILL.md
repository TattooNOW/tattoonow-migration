---
name: ghl-api
description: GoHighLevel (GHL) API reference and usage guide. Use when making GHL API calls, building automations against GHL, looking up endpoint paths, understanding V1 vs V2 differences, OAuth vs PIT auth, or working with contacts/conversations/blogs/calendars/opportunities/payments/products in GHL.
---

# GoHighLevel (GHL) API Expert

Complete reference for the GHL API — all endpoints, auth patterns, version differences, and TattooNOW-specific patterns.

---

## Base URLs & Auth

| Version | Base URL | Auth | Use Case |
|---------|----------|------|----------|
| **V2** (current) | `https://services.leadconnectorhq.com` | `Bearer {PIT or OAuth}` | All standard operations |
| **V1** (legacy) | `https://rest.gohighlevel.com/v1/` | `Bearer {AGENCY_API_KEY}` | Location creation ONLY |

### Required Headers (V2)
```
Authorization: Bearer {token}
Content-Type: application/json
Version: 2021-07-28
```

### Token Types

| Type | Scope | Notes |
|------|-------|-------|
| **PIT** (Private Integration Token) | Per-location | Static, no refresh needed. Rotate every 90 days. Created in GHL UI → Agency Settings → Private Integrations |
| **OAuth Access Token** | Sub-Account or Agency | Expires ~24h. Better for multi-location public apps. |
| **OAuth Refresh Token** | — | Valid 1 year, rotates on use |

### OAuth Endpoints
- **Get token**: `POST https://services.leadconnectorhq.com/oauth/token`
- **Get location token**: `POST https://services.leadconnectorhq.com/oauth/locationToken` (Bearer {access_token} + Version header)
- **Grant types**: `authorization_code`, `refresh_token`

### TattooNOW Config
- **Agency API Key**: Stored in `.env` as `GHL_AGENCY_API_KEY`
- **Company ID**: `Wi9zjVQgZIH2Kk2lnfrg`
- **Snapshot ID**: `kwq6O3LdhQrLdJGozmZ4`
- **PIT storage**: In Airtable task Notes, `migrationMeta` HTML comment, key `"ghlPit"`
- **Blog site ID storage**: Same comment, key `"ghlBlogId"`

---

## CRITICAL: V1 vs V2 Rule

**Only use V1 for location creation. Use V2 for everything else.**

| Task | Version | Why |
|------|---------|-----|
| Create location/sub-account | **V1 only** | No V2 equivalent exists |
| All other operations | **V2** | V1 is legacy/deprecated |
| `snapshotId` in V1 create | Silently ignored | Must load snapshot manually in GHL UI after creation |

---

## API Endpoints by Category

### CONTACTS

```
GET    /contacts/:contactId              Get contact
POST   /contacts/                        Create contact
PUT    /contacts/:contactId              Update contact
DELETE /contacts/:contactId              Delete contact
POST   /contacts/upsert                 Upsert contact
GET    /contacts/                        Get contacts (paginated)
GET    /contacts/business/:businessId   Get contacts by business
GET    /contacts/search                 Search contacts (advanced)
GET    /contacts/lookup                 Check for duplicates

# Tasks
GET    /contacts/:id/tasks              List tasks
POST   /contacts/:id/tasks              Create task
GET    /contacts/:id/tasks/:taskId      Get task
PUT    /contacts/:id/tasks/:taskId      Update task
DELETE /contacts/:id/tasks/:taskId      Delete task
PUT    /contacts/:id/tasks/:taskId/completed  Mark complete

# Notes
GET    /contacts/:id/notes              List notes
POST   /contacts/:id/notes              Create note
GET    /contacts/:id/notes/:noteId      Get note
PUT    /contacts/:id/notes/:noteId      Update note
DELETE /contacts/:id/notes/:noteId      Delete note

# Tags
POST   /contacts/:id/tags               Add tags
DELETE /contacts/:id/tags               Remove tags

# Campaigns
POST   /contacts/:id/campaigns/:campaignId    Add to campaign
DELETE /contacts/:id/campaigns/:campaignId    Remove from campaign
DELETE /contacts/:id/campaigns                Remove from all campaigns

# Workflows
POST   /contacts/:id/workflow/:workflowId     Add to workflow
DELETE /contacts/:id/workflow/:workflowId     Remove from workflow

# Other
GET    /contacts/:id/appointments       Get contact appointments
POST   /contacts/:id/followers          Add followers
DELETE /contacts/:id/followers          Remove followers
POST   /contacts/bulk                   Bulk update contacts
```

### CONVERSATIONS & MESSAGES

```
GET    /conversations/:id               Get conversation
POST   /conversations/                  Create conversation
PUT    /conversations/:id               Update conversation
DELETE /conversations/:id               Delete conversation
GET    /conversations/search            Search conversations

# Messages
GET    /conversations/messages                      Export messages (cursor pagination)
GET    /conversations/messages/:messageId           Get message
GET    /conversations/:id/messages                  Get messages in conversation
POST   /conversations/messages                      Send message
POST   /conversations/messages/inbound              Add inbound message
POST   /conversations/messages/outbound             Add outbound call
DELETE /conversations/messages/schedule/:msgId      Cancel scheduled message
POST   /conversations/messages/upload               Upload attachments (max 5MB/file, 5 files)
PUT    /conversations/messages/:messageId/status    Update message status
PUT    /conversations/messages/attachments          Add message attachments (max 5 URLs)

# Recordings & Transcriptions
GET    /conversations/messages/:msgId/locations/:locId/recording       Get recording
GET    /conversations/messages/:msgId/locations/:locId/transcription   Get transcription
GET    /conversations/messages/:msgId/locations/:locId/transcription/download  Download

# Email
GET    /conversations/:id/messages/email/:emailMessageId   Get email message
```

### OPPORTUNITIES & PIPELINES

```
GET    /opportunities/:id               Get opportunity
POST   /opportunities/                  Create opportunity
PUT    /opportunities/:id               Update opportunity
DELETE /opportunities/:id               Delete opportunity
PUT    /opportunities/:id/status        Update status
POST   /opportunities/upsert            Upsert opportunity
GET    /opportunities/search            Search opportunities

# Pipelines
GET    /opportunities/pipelines         Get all pipelines for location

# Lost Reasons
GET    /opportunities/lost-reasons      List lost reasons
POST   /opportunities/lost-reasons      Create lost reason
PUT    /opportunities/lost-reasons/:id  Update lost reason
DELETE /opportunities/lost-reasons/:id  Delete lost reason

# Followers
POST   /opportunities/:id/followers     Add followers
DELETE /opportunities/:id/followers     Remove followers
```

### CALENDARS & APPOINTMENTS

```
GET    /calendars/                          List calendars
POST   /calendars/                          Create calendar
GET    /calendars/:id                       Get calendar
PUT    /calendars/:id                       Update calendar
DELETE /calendars/:id                       Delete calendar
GET    /calendars/:id/free-slots            Get available slots (requires date range)

# Groups
GET    /calendars/groups                    List groups
POST   /calendars/groups                    Create group
PUT    /calendars/groups/:groupId           Update group
DELETE /calendars/groups/:groupId           Delete group
PUT    /calendars/groups/:groupId/status    Enable/disable group
GET    /calendars/groups/:groupId/slugs     Validate slug

# Events / Appointments
POST   /calendars/events/appointments               Create appointment
PUT    /calendars/events/appointments/:eventId      Update appointment
GET    /calendars/events/appointments/:id           Get appointment
GET    /calendars/events                            Get events
GET    /calendars/events/blocked-slots              Get blocked slots
POST   /calendars/events/block-slots                Create block slot
PUT    /calendars/events/block-slots/:eventId       Update block slot
DELETE /calendars/events/:eventId                   Delete event

# Appointment Notes
GET    /calendars/events/appointments/:id/notes             List notes
POST   /calendars/events/appointments/:id/notes             Create note
PUT    /calendars/events/appointments/:id/notes/:noteId     Update note
DELETE /calendars/events/appointments/:id/notes/:noteId     Delete note

# Notifications
GET    /calendars/:id/notifications             List notifications
POST   /calendars/:id/notifications             Create notification
GET    /calendars/:id/notifications/:noteId     Get notification
PUT    /calendars/:id/notifications/:noteId     Update notification
DELETE /calendars/:id/notifications/:noteId     Delete notification

# Resources
GET    /calendars/resources/equipments          List equipment
POST   /calendars/resources/equipments          Create equipment
GET    /calendars/resources/equipments/:id      Get equipment
PUT    /calendars/resources/equipments/:id      Update equipment
DELETE /calendars/resources/equipments/:id      Delete equipment
GET    /calendars/resources/rooms               List rooms
POST   /calendars/resources/rooms               Create room
GET    /calendars/resources/rooms/:id           Get room
PUT    /calendars/resources/rooms/:id           Update room
DELETE /calendars/resources/rooms/:id           Delete room
```

### BLOGS

```
GET    /blogs/site/all?locationId=X&limit=20&skip=0    Get blog sites (returns _id = blogId)
GET    /blogs/authors?locationId=X&limit=10&offset=0   Get blog authors
GET    /blogs/categories?locationId=X&limit=10&offset=0 Get categories
GET    /blogs/posts?locationId=X&blogId=X              Get posts
POST   /blogs/posts                                     Create blog post
PUT    /blogs/posts/:postId                             Update blog post
GET    /blogs/check-slug                                Check slug availability
```

**Create/Update Blog Post body:**
```json
{
  "locationId": "required",
  "blogId": "required (from /blogs/site/all → _id)",
  "title": "required",
  "rawHTML": "<p>Content</p>",
  "status": "PUBLISHED | DRAFT",
  "authorId": "optional",
  "categories": ["optional"],
  "tags": ["optional"],
  "imageUrl": "optional",
  "description": "optional (meta description)",
  "urlSlug": "optional"
}
```

**OAuth Scopes needed for blogs:**
- `blogs/list.readonly`, `blogs/author.readonly`, `blogs/category.readonly`
- `blogs/posts.readonly`, `blogs/post.write`, `blogs/post-update.write`
- `blogs/check-slug.readonly`

### LOCATIONS / SUB-ACCOUNTS

```
# V2 (standard operations)
GET    /locations/:locationId               Get sub-account details
PUT    /locations/:locationId               Update sub-account
DELETE /locations/:locationId               Delete sub-account
GET    /locations/search                    Search locations
GET    /locations/timezones                 Get timezones list
GET    /locations/:id/tasks/search          Search location tasks

# V1 ONLY (location creation)
POST   https://rest.gohighlevel.com/v1/locations/           Create location
GET    https://rest.gohighlevel.com/v1/locations/?companyId=X  List locations

# Custom Fields
GET    /locations/:id/customFields          List custom fields
POST   /locations/:id/customFields          Create custom field
GET    /locations/:id/customFields/:fid     Get custom field
PUT    /locations/:id/customFields/:fid     Update custom field
DELETE /locations/:id/customFields/:fid     Delete custom field
POST   /locations/:id/customFields/upload   Upload file to custom field

# Custom Values
GET    /locations/:id/customValues          List custom values
POST   /locations/:id/customValues          Create custom value
GET    /locations/:id/customValues/:vid     Get custom value
PUT    /locations/:id/customValues/:vid     Update custom value
DELETE /locations/:id/customValues/:vid     Delete custom value

# Tags
GET    /locations/:id/tags                  List tags
POST   /locations/:id/tags                  Create tag
GET    /locations/:id/tags/:tagId           Get tag
PUT    /locations/:id/tags/:tagId           Update tag
DELETE /locations/:id/tags/:tagId           Delete tag

# Templates
GET    /locations/:id/templates             Get templates
DELETE /locations/:id/templates/:tid        Delete template
```

### USERS

```
GET    /users/:userId       Get user
POST   /users/              Create user
PUT    /users/:userId       Update user
DELETE /users/:userId       Delete user
GET    /users/search        Search users
```

### WORKFLOWS & CAMPAIGNS

```
GET    /workflows/          Get all workflows for location
GET    /campaigns/          Get campaigns
```

### SOCIAL PLANNER

```
GET    /social-media-posting/posts                  List posts
POST   /social-media-posting/posts                  Create post
GET    /social-media-posting/posts/:postId          Get post
PUT    /social-media-posting/posts/:postId          Update post
DELETE /social-media-posting/posts/:postId          Delete post
POST   /social-media-posting/posts/bulk-delete      Bulk delete

GET    /social-media-posting/accounts               Get social accounts
DELETE /social-media-posting/accounts/:accountId    Delete account
GET    /social-media-posting/categories             List categories
GET    /social-media-posting/categories/:id         Get category
GET    /social-media-posting/tags                   Get tags
GET    /social-media-posting/platform-accounts      Get platform accounts

# OAuth connections
POST   /social-media-posting/oauth/google/start     Google OAuth
POST   /social-media-posting/oauth/facebook/start   Facebook OAuth
POST   /social-media-posting/oauth/instagram/start  Instagram OAuth
POST   /social-media-posting/oauth/tiktok/start     TikTok OAuth
```

### EMAIL

```
GET    /emails/campaigns                    List campaigns
GET    /emails/builder/templates            List email templates
POST   /emails/builder/templates            Create template
PUT    /emails/builder/templates/:id        Update template
DELETE /emails/builder/templates/:id        Delete template
```

### INVOICES

```
GET    /invoices/                               List invoices
POST   /invoices/                               Create invoice
GET    /invoices/:id                            Get invoice
PUT    /invoices/:id                            Update invoice
DELETE /invoices/:id                            Delete invoice
PUT    /invoices/:id/late-fees                  Update late fees
POST   /invoices/:id/send                       Send invoice
POST   /invoices/:id/record-payment             Record payment
GET    /invoices/generate-invoice-number        Generate invoice number

# Templates
GET    /invoices/template                       List templates
POST   /invoices/template                       Create template
GET    /invoices/template/:id                   Get template
PUT    /invoices/template/:id                   Update template
DELETE /invoices/template/:id                   Delete template

# Schedules
GET    /invoices/schedule                       List schedules
POST   /invoices/schedule                       Create schedule
GET    /invoices/schedule/:id                   Get schedule
PUT    /invoices/schedule/:id                   Update schedule
DELETE /invoices/schedule/:id                   Delete schedule

# Estimates
GET    /invoices/estimate                       List estimates
POST   /invoices/estimate                       Create estimate
GET    /invoices/estimate/:id                   Get estimate
PUT    /invoices/estimate/:id                   Update estimate
DELETE /invoices/estimate/:id                   Delete estimate
POST   /invoices/estimate/:id/send              Send estimate
POST   /invoices/estimate/:id/invoice           Create invoice from estimate
GET    /invoices/estimate/generate-number       Generate estimate number
```

### PAYMENTS & ORDERS

```
GET    /payments/orders                         List orders
GET    /payments/orders/:orderId                Get order
POST   /payments/orders/:orderId/fulfillments   Create fulfillment
GET    /payments/orders/:orderId/fulfillments   List fulfillments
GET    /payments/transactions                   List transactions
GET    /payments/transactions/:id               Get transaction
GET    /payments/subscriptions                  List subscriptions
GET    /payments/subscriptions/:id              Get subscription

# Coupons
GET    /payments/coupons                        List coupons
POST   /payments/coupons                        Create coupon
GET    /payments/coupons/:id                    Get coupon
PUT    /payments/coupons/:id                    Update coupon
DELETE /payments/coupons/:id                    Delete coupon

# Custom Payment Providers
POST   /payments/custom-provider/provider           Create provider config
GET    /payments/custom-provider/provider           Get provider config
DELETE /payments/custom-provider/provider/disconnect Disconnect provider
POST   /payments/custom-provider/integration        Create integration
DELETE /payments/custom-provider/integration        Delete integration
```

### PRODUCTS

```
GET    /products/                           List products
POST   /products/                           Create product
GET    /products/:id                        Get product
PUT    /products/:id                        Update product
DELETE /products/:id                        Delete product
POST   /products/bulk-edit                  Bulk edit products/prices (max 30)

# Prices
GET    /products/:id/price                  List prices
POST   /products/:id/price                  Create price
GET    /products/:id/price/:priceId         Get price
PUT    /products/:id/price/:priceId         Update price
DELETE /products/:id/price/:priceId         Delete price

# Collections
GET    /products/collections                List collections
POST   /products/collections                Create collection
GET    /products/collections/:id            Get collection
PUT    /products/collections/:id            Update collection
DELETE /products/collections/:id            Delete collection

# Inventory
GET    /products/inventory                  List inventory
```

### STORE (E-Commerce / Shipping)

```
GET    /store/shipping-zones                        List zones
POST   /store/shipping-zones                        Create zone
GET    /store/shipping-zones/:id                    Get zone
PUT    /store/shipping-zones/:id                    Update zone
DELETE /store/shipping-zones/:id                    Delete zone
GET    /store/shipping-zones/rates/available        Get available rates
GET    /store/shipping-zones/:zoneId/rates          List rates for zone
POST   /store/shipping-zones/:zoneId/rates          Create rate
PUT    /store/shipping-zones/:zoneId/rates/:id      Update rate
DELETE /store/shipping-zones/:zoneId/rates/:id      Delete rate
GET    /store/shipping-carriers                     List carriers
POST   /store/shipping-carriers                     Create carrier
GET    /store/setting                               Get store settings
POST   /store/setting                               Create/update settings
```

### CUSTOM OBJECTS & FIELDS

```
# Custom Objects
GET    /objects/                                Get all object schemas
POST   /objects/                                Create object schema
GET    /objects/:objectKey                      Get schema
PUT    /objects/:objectKey                      Update schema
GET    /objects/:objectKey/records              Search records
POST   /objects/:objectKey/records              Create record
GET    /objects/:objectKey/records/:recordId    Get record
PUT    /objects/:objectKey/records/:recordId    Update record
DELETE /objects/:objectKey/records/:recordId    Delete record

# Associations
GET    /objects/associations                    List associations
POST   /objects/associations                    Create association
GET    /objects/associations/:id                Get association
PUT    /objects/associations/:id                Update association
DELETE /objects/associations/:id                Delete association

# Custom Fields V2
GET    /custom-fields/:id                       Get field or folder
PUT    /custom-fields/:id                       Update field
DELETE /custom-fields/:id                       Delete field
GET    /custom-fields/?objectKey=X              Get fields by object key
POST   /custom-fields/                          Create custom field
POST   /custom-fields/folders                   Create folder
PUT    /custom-fields/folders/:id               Rename folder
DELETE /custom-fields/folders/:id               Delete folder
```

### FORMS & SURVEYS

```
GET    /forms/                              List forms
GET    /forms/submissions                   Get submissions
POST   /forms/upload-custom-fields          Upload files (max 50MB)

GET    /surveys/                            List surveys
GET    /surveys/submissions                 Get submissions
```

### MEDIA

```
GET    /medias/                 List media files
POST   /medias/upload           Upload file
DELETE /medias/:id              Delete file
```

### FUNNELS

```
GET    /funnels/                        List funnels
GET    /funnels/:id                     Get funnel
GET    /funnels/:id/pages               Get funnel pages
GET    /funnels/redirects               List redirects
POST   /funnels/redirects               Create redirect
PUT    /funnels/redirects/:id           Update redirect
DELETE /funnels/redirects/:id           Delete redirect
```

### SNAPSHOTS

```
GET    /snapshots/                      List snapshots
POST   /snapshots/share-link            Create share link
```

### TRIGGER LINKS

```
GET    /links/                          List trigger links
POST   /links/                          Create trigger link
PUT    /links/:linkId                   Update trigger link
DELETE /links/:linkId                   Delete trigger link
GET    /links/search                    Search trigger links
```

### BUSINESSES

```
GET    /businesses/             List businesses for location
POST   /businesses/             Create business
GET    /businesses/:id          Get business
PUT    /businesses/:id          Update business
DELETE /businesses/:id          Delete business
```

### COMPANIES (Agency Level)

```
GET    /companies/:id           Get company
POST   /companies/              Create company
PUT    /companies/:id           Update company
DELETE /companies/:id           Delete company
```

---

## Common Code Patterns

### V2 API Call (PIT auth)
```bash
curl -s -X GET \
  -H "Authorization: Bearer $GHL_PIT" \
  -H "Version: 2021-07-28" \
  -H "Content-Type: application/json" \
  "https://services.leadconnectorhq.com/contacts/?locationId=LOC_ID"
```

### V1 Create Location
```bash
curl -s -X POST \
  -H "Authorization: Bearer $GHL_AGENCY_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"companyId":"Wi9zjVQgZIH2Kk2lnfrg","name":"Studio Name","domain":"example.com"}' \
  "https://rest.gohighlevel.com/v1/locations/"
```

### Get Blog Sites (find blogId)
```bash
curl -s -H "Authorization: Bearer $PIT" -H "Version: 2021-07-28" \
  "https://services.leadconnectorhq.com/blogs/site/all?locationId=LOC_ID&limit=20&skip=0"
# Returns: {"data":[{"_id":"...","name":"..."}]} — use _id as blogId
```

### Create Blog Post
```bash
curl -s -X POST \
  -H "Authorization: Bearer $PIT" \
  -H "Version: 2021-07-28" \
  -H "Content-Type: application/json" \
  -d '{"locationId":"LOC_ID","blogId":"BLOG_ID","title":"Post Title","rawHTML":"<p>Content</p>","status":"PUBLISHED"}' \
  "https://services.leadconnectorhq.com/blogs/posts"
```

### Search Contacts
```bash
curl -s -X POST \
  -H "Authorization: Bearer $PIT" \
  -H "Version: 2021-07-28" \
  -H "Content-Type: application/json" \
  -d '{"locationId":"LOC_ID","query":"email@example.com","page":1,"pageLimit":20}' \
  "https://services.leadconnectorhq.com/contacts/search"
```

### Create Opportunity
```bash
curl -s -X POST \
  -H "Authorization: Bearer $PIT" \
  -H "Version: 2021-07-28" \
  -H "Content-Type: application/json" \
  -d '{"locationId":"LOC_ID","name":"Deal Name","pipelineId":"PIPE_ID","pipelineStageId":"STAGE_ID","contactId":"CONTACT_ID","status":"open"}' \
  "https://services.leadconnectorhq.com/opportunities/"
```

---

## GHL-Specific Behaviors & Gotchas

1. **V1 `snapshotId` is silently ignored** — snapshot loads do not happen via API; must load manually in GHL UI after location creation
2. **Blog `status` values** are `"PUBLISHED"` and `"DRAFT"` (all caps)
3. **Blog site `_id`** from `/blogs/site/all` is the `blogId` needed for post operations
4. **PIT tokens are per-location** — you need a different PIT for each sub-account
5. **Inbound messages** require either `conversationId` or `contactId`
6. **File uploads** via forms: max 50MB, buffer format `<custom_field_id>_<file_id>`
7. **Message attachments**: max 5MB per file, up to 5 files per upload
8. **Pagination**: Most list endpoints use `limit`/`offset` or `limit`/`skip` — not `page`
9. **Location token**: Use `POST /oauth/locationToken` to exchange agency token for per-location token when using OAuth
10. **Rate limits**: GHL doesn't publish exact limits — use exponential backoff on 429 responses

---

## TattooNOW Migration Pipeline Usage

The site migration pipeline stores GHL-specific metadata in Airtable Tasks Notes as an HTML comment:

```html
<!-- migrationMeta: {"ghlPit":"tok_xxx","ghlLocationId":"abc123","ghlBlogId":"blog_xxx","authorId":"auth_xxx","categoryId":"cat_xxx"} -->
```

- `ghlPit` — the PIT token for this location (V2 auth)
- `ghlLocationId` — the GHL sub-account location ID
- `ghlBlogId` — the blog site `_id` (from `/blogs/site/all`)
- `authorId` — blog author ID for posts
- `categoryId` — blog category ID for posts

The migration tools read this metadata from Airtable before making any GHL calls.
