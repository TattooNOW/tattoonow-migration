---
name: airtable-best-practices
description: Resourceful Airtable usage — rate limits, caching, batch ops, upsert patterns, and testing mode for the TattooNOW ops stack
triggers:
  - airtable best practices
  - airtable rate limit
  - airtable api limit
  - airtable batch
  - airtable upsert
  - airtable caching
  - airtable testing mode
  - how should i use airtable
  - airtable quota
  - PUBLIC_API_BILLING_LIMIT
---

# Airtable Best Practices

You are an expert in the Airtable REST API. Apply these rules whenever reading from or writing to Airtable in the TattooNOW ops stack.

---

## Rate Limits

| Tier | Limit | Notes |
|------|-------|-------|
| Free | 1,000 API calls/month (total across all tokens in workspace) | HARD BILLING LIMIT |
| Pro ($20/mo) | 100,000 calls/month | Recommended for production |
| Enterprise | Custom | |

**The #1 rule**: Never call Airtable more than necessary. Every direct `curl` or Python request from Claude Code counts against the monthly quota.

**What burned us on 2026-03-14**: Direct curl commands during debugging (checking Notes fields, patching stages, verifying webhook responses) consumed ~200+ calls in a single session, hitting the monthly limit.

---

## Caching Strategy

### n8n static data cache (implemented in `l0gal5OUMYU8QjlW`)
```js
// In Format Response Code node:
const staticData = $getWorkflowStaticData('global');
if (!input.records) {
  return [{ json: { cached: true, cachedAt: staticData.cacheTimestamp, migrations: staticData.migrationsCache || [] } }];
}
// On success, update cache:
staticData.migrationsCache = migrations;
staticData.cacheTimestamp = new Date().toISOString();
```

### When to cache vs. call live
- **Cache it**: Any data needed by the dashboard (migrations, tasks, projects) — use n8n webhook + static data cache
- **Call live**: Only when writing back to Airtable (stage updates, notes patches)
- **Never cache**: One-time write operations (create record, update field)

---

## Batch Operations

```bash
# Always batch creates/updates — max 10 records per request
# Creates
curl -X POST -H "Authorization: Bearer $AIRTABLE_TOKEN" -H "Content-Type: application/json" \
  -d '{"records": [{"fields": {...}}, {"fields": {...}}]}' \
  "https://api.airtable.com/v0/{baseId}/{tableId}"

# Updates (PATCH — partial update)
curl -X PATCH -H "Authorization: Bearer $AIRTABLE_TOKEN" -H "Content-Type: application/json" \
  -d '{"records": [{"id": "recXXX", "fields": {...}}, {"id": "recYYY", "fields": {...}}]}' \
  "https://api.airtable.com/v0/{baseId}/{tableId}"
```

**Rule**: Never loop 70 records with one request each. Batch in groups of 10.

---

## Native Upsert (saves calls)

```bash
# PATCH with performUpsert — create or update based on unique field
curl -X PATCH -H "Authorization: Bearer $AIRTABLE_TOKEN" -H "Content-Type: application/json" \
  -d '{
    "performUpsert": { "fieldsToMergeOn": ["fldDomainFieldId"] },
    "records": [{"fields": {"fldDomainFieldId": "example.com", "fldStatusId": "Live"}}]
  }' \
  "https://api.airtable.com/v0/{baseId}/{tableId}"
```

Use `performUpsert` whenever syncing external data to Airtable — avoids the read-then-write pattern that doubles your API calls.

---

## Testing Mode

When running or debugging code that touches Airtable, use a **test record approach** rather than calling the live API repeatedly:

1. **Add an `Is Test Record` checkbox field** to the table
2. Set it on records used for testing
3. In your tool/code, add `--dry-run` flag that prints what would be sent without calling the API
4. Gate API calls: `if not dry_run: resp = requests.post(...)` else `print("DRY RUN:", payload)`

```python
# In Python tools (all migrate_*.py):
if args.dry_run:
    result['action'] = 'dry_run'
    result['would_send'] = payload
    print(json.dumps(result, indent=2))
    sys.exit(0)
```

**Never debug by calling the live API repeatedly.** Use `--dry-run` first, then one real call.

---

## Read Strategy

```bash
# Use filterByFormula to read only what you need — don't fetch all 70 records to find one
curl "https://api.airtable.com/v0/{baseId}/{tableId}?filterByFormula={Task}='Migrate: example.com'"

# Use fields[] param to return only the fields you need
curl "https://api.airtable.com/v0/{baseId}/{tableId}?fields[]=fldXXX&fields[]=fldYYY"

# Page through large tables (max 100 per request)
curl "https://api.airtable.com/v0/{baseId}/{tableId}?pageSize=100&offset={offset}"
```

---

## Notes Field Pattern (TattooNOW migrations)

Migration metadata is stored as HTML comments in the Notes field:
```
<!-- pipelineStage: GHL Setup -->
<!-- stageData: {"ghlLocationId":"XiUPFeURoAVRM7DU62AI"} -->
<!-- migrationMeta: {"client":"Ghost in the Tattoo Machine","pilot":true,"ghlPit":"..."} -->
```

**When updating Notes**: Always read the current Notes first, update only the comment you need, PATCH back the full Notes string. Never overwrite the entire Notes field without preserving existing content.

---

## PAT Token Scopes

The token in `CLAUDE.md` (`patCSx69GGyUXZu8s...`) has these scopes:
- `data.records:read` — read records
- `data.records:write` — create/update/delete records
- `schema.bases:read` — read table schema

It does NOT have `schema.bases:write` — cannot create tables or add fields via API. Use the Airtable UI for schema changes.

---

## Monthly Call Budget (Free Tier)

| Operation | Calls | Notes |
|-----------|-------|-------|
| Load migrations webhook (1 fetch) | 1 | Covers 100 records |
| Update stage for 1 domain | 1 | PATCH single record |
| Full debug session (read + patch + verify) | 10-50 | Kills the month fast |

**Budget rule**: If you need to read + write + verify → that's 3 calls minimum. Budget accordingly.

**Claude Code Claude direct calls (AVOID)**: Every `curl` or Python request from Claude Code directly counts. Use n8n as the API layer. Claude Code should only trigger n8n webhooks, not call Airtable directly.

---

## When Airtable is Rate Limited

The dashboard at brain.tattoonow.com will show an amber banner: "Showing cached data from [date]". This is expected — the n8n workflow serves cached data from `$getWorkflowStaticData('global')`. Data refreshes automatically when the billing limit resets (monthly).

Do NOT try to "fix" this by calling the API again — it will fail. Wait for the monthly reset.
